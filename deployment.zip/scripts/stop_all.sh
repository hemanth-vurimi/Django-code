#!/bin/bash
fuser -k 8000/tcp

