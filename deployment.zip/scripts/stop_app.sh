#!/bin/bash
echo "Stopping Django app..."
pkill -f gunicorn
